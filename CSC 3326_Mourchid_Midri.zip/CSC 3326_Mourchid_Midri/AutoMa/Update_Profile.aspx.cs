﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class Update_Profile : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        SqlConnection dbConnection = new SqlConnection();
        dbConnection.ConnectionString =
        "server=192.168.3.4;user=mansouri;password=meryem;database=mansouri";
        dbConnection.Open();
        string retString = "Update Manager set firstname ='" + first_name.Text + "', lastname = '" + last_name.Text + "', Addres = '" + Address.Text + "', email='" + email.Text +"', phone_number='"+ Phone_Number.Text + "' where (Select Manager_ID from Manager ) = 0";
        SqlCommand qryCommand = new SqlCommand(retString, dbConnection);
        SqlDataReader prodRecords = qryCommand.ExecuteReader();
        if (prodRecords.Read())
        {
            do
            {
                Response.Redirect("Dashboard.aspx");
            } while (prodRecords.Read()); 
        }
        prodRecords.Close();
        dbConnection.Close();

    }
}