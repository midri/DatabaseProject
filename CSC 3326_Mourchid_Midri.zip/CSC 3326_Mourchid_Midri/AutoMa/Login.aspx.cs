﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string user;
        SqlConnection dbConnection = new SqlConnection();
        dbConnection.ConnectionString =
        "server=192.168.3.4;user=mansouri;password=meryem;database=mansouri";
        dbConnection.Open();
        user = user_name.Text;
        string retString = "SELECT customer_ID, password from Customer where username = '" + user_name.Text +"' AND password  = '" + password_name.Text +"'";
        SqlCommand qryCommand = new SqlCommand(retString, dbConnection);
        SqlDataReader prodRecords = qryCommand.ExecuteReader();
        if (prodRecords.Read())
        {
            do
            {
                Response.Redirect("Dashboard.aspx");
            } while (prodRecords.Read());
        }
        prodRecords.Close();
        dbConnection.Close();

    }
}