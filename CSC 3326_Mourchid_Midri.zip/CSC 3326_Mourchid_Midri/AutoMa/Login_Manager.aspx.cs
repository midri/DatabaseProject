﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class Login_Manager : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        SqlConnection dbConnection = new SqlConnection();
        dbConnection.ConnectionString =
        "server=192.168.3.4;user=mansouri;password=meryem;database=mansouri";
        dbConnection.Open();
        string retString1 = "SELECT Manager_ID, M_password from Manager where Manager_ID = '" + Usern.Text + "' AND M_password  = '" + password.Text + "'";
        SqlCommand qryCommand1= new SqlCommand(retString1, dbConnection);
        SqlDataReader prodRecords1 = qryCommand1.ExecuteReader();
        if (prodRecords1.Read())
        {
            do
            {
                Response.Redirect("Dashboard.aspx");
            } while (prodRecords1.Read());
        }
        prodRecords1.Close();
        dbConnection.Close();

    }
}